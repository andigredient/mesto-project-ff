import { initialCards } from "./cards.js";
import {closeModal, openModal} from './modal.js';
import { deleteCards, createCards, likeToCard } from './card.js';
import './pages/index.css';

const popup = document.querySelector('.popup');
const placesList = document.querySelector('.places__list');
const cardTemplate = document.querySelector('#card-template').content;
const buttonEdit = document.querySelector('.profile__edit-button');
const popupEdit = document.querySelector('.popup_type_edit');
const buttonAdd = document.querySelector('.profile__add-button');
const popupAdd = document.querySelector('.popup_type_new-card');
const popupImage = document.querySelector('.popup_type_image');
const scrImage = document.querySelector('.popup__image');
const popupTitle = document.querySelector('.popup__caption');
const buttonClose = document.querySelectorAll('.popup__close'); 
const inputPopupName = document.querySelector('.popup__input_type_name');
const inputPopupDescription = document.querySelector('.popup__input_type_description');
const profileTitle = document.querySelector('.profile__title');
const profileDescription = document.querySelector('.profile__description');
const popupButton = document.querySelector('.popup__button');
const formEditProfile = document.forms['edit-profile'];
const nameInput = formEditProfile.name;
const jobInput = formEditProfile.description;
const formAddCard = document.forms['new-place'];
const titleInput = formAddCard['place-name'];
const linkInput = formAddCard.link;

addCards ();  

function addCards() {
  initialCards.forEach (card =>  placesList.append(createCards(card, deleteCards, likeToCard, popupImgOpened)));
}

function handleFormSubmitEdit(evt) {
  evt.preventDefault();
  //nameInput.value = '';
  //jobInput.value = '';
  profileTitle.textContent = nameInput.value;
  profileDescription.textContent = jobInput.value;
  formEditProfile.reset();
  closeModal(popup);
}

function handleFormSubmitAdd(evt) {
  evt.preventDefault();
  const newCard = {
    name: titleInput.value,
    link: linkInput.value 
  }
  placesList.prepend(createCards(newCard, deleteCards, likeToCard, popupImgOpened));  
  const cardImagePopup = document.querySelectorAll('.card__image');
  cardImagePopup.forEach(popupImgOpened);
  closeModal(document.querySelector('.popup_is-opened'));
}

const cardImagePopup = document.querySelectorAll('.card__image');

export { cardTemplate, inputPopupName, inputPopupDescription, profileTitle, profileDescription, popupButton, nameInput, jobInput, titleInput, linkInput, placesList}

formEditProfile.addEventListener('submit', handleFormSubmitEdit);
formAddCard.addEventListener('submit', handleFormSubmitAdd);

  //попап с редактированием
  buttonEdit.addEventListener('click', function() {
    popupEdit.classList.add('popup_is-opened');
    openModal();
  })
  
  //попап с добавлением картинки
buttonAdd.addEventListener('click', function() {
  popupAdd.classList.add('popup_is-opened');
  openModal();
})

//попап с картинками
cardImagePopup.forEach(popupImgOpened)

  function popupImgOpened (image) {
  image.addEventListener('click', function(evt) {
    popupImage.classList.add('popup_is-opened');
    scrImage.setAttribute('src',image.src);
    scrImage.setAttribute('alt',image.alt);
    popupTitle.textContent = image.alt;
    openModal();
  })
}

//закрытие на крестик  
buttonClose.forEach( function (item) {
  const popup = item.closest('.popup');
  item.addEventListener('click', function () {
    closeModal(popup)
  });
});

export { popupImgOpened, addCards }
