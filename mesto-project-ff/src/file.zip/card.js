import { initialCards } from "./cards.js";
import { cardTemplate, profileTitle, profileDescription, nameInput, jobInput, titleInput, linkInput, popupImgOpened, placesList } from "./index.js";
import { closeModal, openModal } from "./modal.js";



function createCards (item, deleteCards, likeToCard, popupImgOpened) {
    const element = cardTemplate.cloneNode(true);
    element.querySelector('.card__title').textContent = item.name;
    const cardImage = element.querySelector('.card__image');
    cardImage.src = item.link;
    cardImage.alt = item.name;
    element.querySelector('.card__delete-button').addEventListener('click', deleteCards);
    element.querySelector('.card__like-button').addEventListener('click', likeToCard);
    cardImage.addEventListener('click', openModal);
    return element;
}



function deleteCards (evt) {
  const eventTarget = evt.target.closest('.places__item');
    eventTarget.remove();    
  }

//лайк
function likeToCard (evt) {  
  if (evt.target.classList.contains('card__like-button')) {
      evt.target.classList.toggle('card__like-button_is-active'); 
  }
}










export {createCards, deleteCards, likeToCard }







