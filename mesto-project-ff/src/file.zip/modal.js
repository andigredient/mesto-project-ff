export {closeModal, openModal, closeToOverlay, closeEscModal}

function closeModal (popup) {
popup.classList.remove('popup_is-opened');
document.removeEventListener('keydown', closeEscModal);
document.removeEventListener('click', closeToOverlay);
}

function openModal (popup) {
popup.classList.add('popup_is-opened');
document.addEventListener('keydown', closeEscModal);
document.addEventListener('click', closeToOverlay);
}

//закрытие на оверлей
function closeToOverlay(evt) {
    const popupIsOpened = document.querySelector('.popup_is-opened');
    if (evt.target === popupIsOpened) {
      closeModal(popupIsOpened);
    }
  }

//закрытие по клавиатуре
function closeEscModal (evt) {
    if (evt.key === 'Escape') {
      closeModal(popupIsOpened);
    }
  }